# Physics Study Planner — Android project

This is the Android WebView app version of the Class 12 Physics Study Planner.
It bundles the timetable UI and corrected study-pack PDF as local app assets.

## APK build
This environment does not have the Android SDK/Gradle installed, so it cannot
compile the APK directly here. The included GitHub Actions workflow builds a
debug APK automatically when the project is pushed to a GitHub repository or
when the workflow is manually run.

Artifact path produced by the build:
`app/build/outputs/apk/debug/app-debug.apk`

The APK is a debug build intended for personal installation/testing.
